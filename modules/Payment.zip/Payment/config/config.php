<?php

return [
    'name' => 'Payment',
];
